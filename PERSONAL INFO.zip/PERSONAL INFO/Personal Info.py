def Personal_Info():
    Name = input("Enter your name? ")
    Age = int(input("Enter your age? "))
    while not Age > 0:
        print("Opps.. looks like you have entered incorrect age.")
        Age = int(input("Enter your age? "))
    Salary = float(input("Enter your salary? "))
    while not Salary > 0:
        print("Please enter correct salary.")
        Salary = float(input("Enter your salary? "))
    print(f"Hello, {Name}, you are {Age} years old and your salary is ${Salary}.")

while True:
    Personal_Info()
    user_input = input('Do you want to run the program again? yes / no :').strip().lower()  
    if user_input not in ['yes' , 'y']:
        print('Exiting...')
        break